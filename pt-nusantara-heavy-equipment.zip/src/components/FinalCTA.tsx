import React from 'react';
import { HERO_BG_IMAGE } from '../data';
import { PhoneCall, MessageCirclePlus } from 'lucide-react';

interface FinalCTAProps {
  onMintaPenawaranClick: () => void;
}

export default function FinalCTA({ onMintaPenawaranClick }: FinalCTAProps) {
  // WhatsApp redirect with pre-filled Indonesian text
  const waUrl = 'https://wa.me/628123456789?text=Halo%20PT%20Nusantara,%20saya%2520ingin%2520bertanya%2520tentang%2520penyewaan%252520alat%252520berat%252520untuk%252520proyek%252520saya.';

  return (
    <section className="relative py-24 overflow-hidden text-white font-sans bg-primary">
      {/* Background visual with grayscale overlay */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-primary/90 mix-blend-multiply z-10" />
        <img
          alt="Alat Berat Konstruksi Pendukung Proyek"
          className="w-full h-full object-cover grayscale opacity-30 scale-102"
          src={HERO_BG_IMAGE}
          referrerPolicy="no-referrer"
        />
      </div>

      <div className="relative z-20 max-w-5xl mx-auto px-6 text-center space-y-8">
        <div className="space-y-4">
          <span className="text-secondary-container font-display font-extrabold text-xs uppercase tracking-widest block">
            Konsultasi Gratis Sekarang
          </span>
          <h2 className="font-display font-extrabold text-3xl md:text-5xl text-white mb-4 leading-tight tracking-tight">
            Siap Mendukung Kesuksesan Proyek Anda
          </h2>
          <p className="text-slate-300 text-sm md:text-base max-w-2xl mx-auto leading-relaxed">
            Hubungi tim ahli kami sekarang untuk mendapatkan konsultasi gratis mengenai spesifikasi alat berat, 
            ketersediaan armada, serta estimasi penawaran harga terbaik untuk proyek konstruksi Anda.
          </p>
        </div>

        {/* Action triggers */}
        <div className="flex flex-wrap justify-center gap-4">
          <a
            href={waUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-[#25D366] hover:brightness-110 active:scale-95 text-white px-8 py-4 rounded-lg font-display font-bold text-sm flex items-center justify-center gap-2.5 shadow-md hover:shadow-lg transition-all"
          >
            {/* Simple Inline SVG for WA or Lucide PhoneCall/MessageCirclePlus */}
            <MessageCirclePlus className="w-5.5 h-5.5 text-white" />
            <span>WhatsApp Chat</span>
          </a>

          <button
            onClick={onMintaPenawaranClick}
            className="bg-secondary-container hover:brightness-110 active:scale-95 text-primary px-8 py-4 rounded-lg font-display font-black text-sm shadow-md hover:shadow-lg transition-all"
          >
            Minta Penawaran Harga
          </button>
        </div>
      </div>
    </section>
  );
}
