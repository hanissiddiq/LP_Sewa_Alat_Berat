import React from 'react';

export default function Process() {
  const steps = [
    {
      number: 1,
      title: 'Konsultasi Kebutuhan',
      description: 'Hubungi tim kami untuk konsultasi unit yang sesuai dengan medan kerja dan jenis proyek Anda.'
    },
    {
      number: 2,
      title: 'Penawaran Harga',
      description: 'Dapatkan surat penawaran resmi (Quotation) dengan rincian biaya transparan tanpa biaya tersembunyi.'
    },
    {
      number: 3,
      title: 'Pengiriman Unit',
      description: 'Unit dikirim ke lokasi proyek secara tepat waktu menggunakan armada trailer/tronton internal kami.'
    },
    {
      number: 4,
      title: 'Monitoring & Support',
      description: 'Dukungan penuh operasional, penggantian unit jika kendala mayor, dan monitoring teknis rutin.'
    }
  ];

  return (
    <section className="py-24 bg-white font-sans">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Heading */}
        <div className="text-center mb-16">
          <span className="text-secondary-container font-bold text-xs uppercase tracking-widest block mb-1">
            Alur Kerja Sederhana
          </span>
          <h2 className="font-display font-extrabold text-2xl md:text-4xl text-primary mb-4 leading-tight">
            Proses Penyewaan
          </h2>
          <p className="text-slate-500 text-sm md:text-base max-w-xl mx-auto font-normal">
            Langkah mudah untuk mendapatkan dukungan alat berat terbaik untuk kelancaran pengerjaan proyek Anda.
          </p>
          <div className="w-16 h-1 bg-secondary-container mx-auto rounded-full mt-4" />
        </div>

        {/* Timeline Grid */}
        <div className="relative">
          {/* Connector Line in desktop */}
          <div className="absolute top-1/2 left-0 w-full h-0.5 bg-slate-200 hidden lg:block -translate-y-1/2 z-0" />
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 relative z-10">
            {steps.map((step) => (
              <div
                key={step.number}
                className="bg-slate-50 p-8 rounded-2xl border border-slate-250 text-center space-y-4 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center mx-auto text-xl font-display font-black border-4 border-white shadow-md">
                  {step.number}
                </div>
                <h3 className="font-display font-extrabold text-primary text-base">
                  {step.title}
                </h3>
                <p className="text-slate-600 text-xs leading-relaxed">
                  {step.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
