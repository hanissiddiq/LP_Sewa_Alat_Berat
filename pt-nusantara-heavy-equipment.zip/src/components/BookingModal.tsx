import React, { useState, useEffect } from 'react';
import { Equipment, Inquiry } from '../types';
import { X, Calendar, Check, Calculator, Shield, User, Mail, Phone, MessageSquare } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedEquipment: Equipment | null;
  equipmentsList: Equipment[];
  onInquirySubmitted: (inquiry: Inquiry) => void;
}

export default function BookingModal({
  isOpen,
  onClose,
  selectedEquipment,
  equipmentsList,
  onInquirySubmitted
}: BookingModalProps) {
  const [equipmentId, setEquipmentId] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [startDate, setStartDate] = useState('');
  const [duration, setDuration] = useState(1);
  const [isOperatorNeeded, setIsOperatorNeeded] = useState(true);
  const [notes, setNotes] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (selectedEquipment) {
      setEquipmentId(selectedEquipment.id);
    } else if (equipmentsList.length > 0) {
      setEquipmentId(equipmentsList[0].id);
    }
  }, [selectedEquipment, equipmentsList]);

  const currentEquipment = equipmentsList.find((e) => e.id === equipmentId);

  // Extract base numerical rate for estimation
  const getEstimatedPrice = () => {
    if (!currentEquipment) return 0;
    // Rental price format is "Rp 4.200.000 / Shift"
    const numbersOnly = currentEquipment.rentalPrice.replace(/[^0-9]/g, '');
    const pricePerShift = parseInt(numbersOnly, 10) || 0;
    
    let base = pricePerShift * duration;
    if (isOperatorNeeded) {
      base += 500000 * duration; // Add Rp 500.000/shift for operators
    }
    return base;
  };

  const formatRupiah = (num: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(num);
  };

  const validateForm = () => {
    const errors: Record<string, string> = {};
    if (!customerName.trim()) errors.customerName = 'Nama lengkap wajib diisi';
    if (!customerEmail.trim()) {
      errors.customerEmail = 'Email wajib diisi';
    } else if (!/\S+@\S+\.\S+/.test(customerEmail)) {
      errors.customerEmail = 'Format email tidak valid';
    }
    if (!customerPhone.trim()) {
      errors.customerPhone = 'Nomor telepon wajib diisi';
    } else if (customerPhone.trim().length < 8) {
      errors.customerPhone = 'Nomor telepon minimal 8 digit';
    }
    if (!startDate) errors.startDate = 'Tanggal sewa wajib ditentukan';
    if (duration <= 0) errors.duration = 'Durasi minimal 1 shift/hari';

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm() || !currentEquipment) return;

    const newInquiry: Inquiry = {
      id: `inq-${Date.now()}`,
      equipmentId: currentEquipment.id,
      equipmentName: currentEquipment.name,
      customerName,
      customerEmail,
      customerPhone,
      startDate,
      duration,
      isOperatorNeeded,
      notes,
      createdAt: new Date().toISOString(),
      status: 'Pending'
    };

    onInquirySubmitted(newInquiry);
    setIsSubmitted(true);
    
    // Reset form states after success presentation
    setTimeout(() => {
      setIsSubmitted(false);
      setCustomerName('');
      setCustomerEmail('');
      setCustomerPhone('');
      setStartDate('');
      setDuration(1);
      setIsOperatorNeeded(true);
      setNotes('');
      onClose();
    }, 3000);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/60 backdrop-blur-xs"
          />

          {/* Modal Card */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ type: 'spring', duration: 0.4 }}
            className="relative w-full max-w-2xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden z-10 max-h-[90vh] flex flex-col"
          >
            {/* Header */}
            <div className="bg-primary text-white px-6 py-4 flex justify-between items-center">
              <div>
                <h3 className="font-display font-semibold text-lg text-white">Formulir Sewa Alat Berat</h3>
                <p className="text-xs text-white/80 font-sans">Dapatkan surat penawaran resmi dari tim estimasi PT Nusantara</p>
              </div>
              <button
                onClick={onClose}
                className="text-white/80 hover:text-white hover:bg-white/10 p-1.5 rounded-lg transition-colors"
                id="close-modal-btn"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content Container */}
            <div className="p-6 overflow-y-auto flex-1 font-sans">
              {isSubmitted ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex flex-col items-center justify-center py-12 text-center"
                >
                  <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mb-4 border border-emerald-300">
                    <Check className="w-8 h-8 text-emerald-600" />
                  </div>
                  <h4 className="font-display font-bold text-xl text-primary mb-2">Permintaan Terkirim!</h4>
                  <p className="text-slate-600 max-w-md text-sm leading-relaxed mb-4">
                    Terima kasih <strong>{customerName}</strong>. Permintaan penawaran harga untuk{' '}
                    <strong>{currentEquipment?.name}</strong> telah berhasil didaftarkan di sistem kami.
                  </p>
                  <div className="p-3 bg-slate-50 border border-slate-100 rounded-lg text-xs text-slate-500 max-w-md">
                    Estimator kami akan menghubungi Anda via Email/WhatsApp dalam waktu maks. 30 menit dengan penawaran resmi (Quotation).
                  </div>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  {/* Select Equipment */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                      Pilih Unit Alat Berat
                    </label>
                    <select
                      value={equipmentId}
                      onChange={(e) => setEquipmentId(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white text-slate-800 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                    >
                      {equipmentsList.map((eq) => (
                        <option key={eq.id} value={eq.id}>
                          {eq.name} ({eq.category} - {eq.model})
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Pricing info banner */}
                  {currentEquipment && (
                    <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg flex items-start gap-3">
                      <img
                        src={currentEquipment.image}
                        alt={currentEquipment.name}
                        className="w-16 h-12 object-cover rounded-md border border-slate-300 flex-shrink-0"
                        referrerPolicy="no-referrer"
                      />
                      <div className="text-xs">
                        <div className="font-bold text-slate-800">{currentEquipment.name}</div>
                        <div className="text-slate-500 mb-1">{currentEquipment.model}</div>
                        <div className="flex gap-3 text-slate-600 font-semibold">
                          <span>Tarif Dasar: <strong className="text-primary">{currentEquipment.rentalPrice}</strong></span>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Grid fields for personal info */}
                  <div className="grid md:grid-cols-2 gap-4">
                    {/* Name */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                        Nama Lengkap Anda
                      </label>
                      <div className="relative">
                        <User className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                        <input
                          type="text"
                          value={customerName}
                          onChange={(e) => setCustomerName(e.target.value)}
                          placeholder="Contoh: Budi Santoso"
                          className={`w-full pl-9 pr-3 py-2 border rounded-lg text-sm bg-white text-slate-800 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary ${
                            formErrors.customerName ? 'border-red-500' : 'border-slate-300'
                          }`}
                        />
                      </div>
                      {formErrors.customerName && (
                        <p className="text-red-500 text-xs mt-0.5">{formErrors.customerName}</p>
                      )}
                    </div>

                    {/* Email */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                        Alamat Email Perusahaan / Pribadi
                      </label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                        <input
                          type="email"
                          value={customerEmail}
                          onChange={(e) => setCustomerEmail(e.target.value)}
                          placeholder="budis@perusahaan.co.id"
                          className={`w-full pl-9 pr-3 py-2 border rounded-lg text-sm bg-white text-slate-800 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary ${
                            formErrors.customerEmail ? 'border-red-500' : 'border-slate-300'
                          }`}
                        />
                      </div>
                      {formErrors.customerEmail && (
                        <p className="text-red-500 text-xs mt-0.5">{formErrors.customerEmail}</p>
                      )}
                    </div>

                    {/* Phone */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                        Nomor WhatsApp / Telp (Aktif)
                      </label>
                      <div className="relative">
                        <Phone className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                        <input
                          type="tel"
                          value={customerPhone}
                          onChange={(e) => setCustomerPhone(e.target.value)}
                          placeholder="Contoh: 081234567890"
                          className={`w-full pl-9 pr-3 py-2 border rounded-lg text-sm bg-white text-slate-800 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary ${
                            formErrors.customerPhone ? 'border-red-500' : 'border-slate-300'
                          }`}
                        />
                      </div>
                      {formErrors.customerPhone && (
                        <p className="text-red-500 text-xs mt-0.5">{formErrors.customerPhone}</p>
                      )}
                    </div>

                    {/* Start Date */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                        Tanggal Mulai Sewa
                      </label>
                      <div className="relative">
                        <Calendar className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                        <input
                          type="date"
                          value={startDate}
                          onChange={(e) => setStartDate(e.target.value)}
                          className={`w-full pl-9 pr-3 py-2 border rounded-lg text-sm bg-white text-slate-800 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary ${
                            formErrors.startDate ? 'border-red-500' : 'border-slate-300'
                          }`}
                        />
                      </div>
                      {formErrors.startDate && (
                        <p className="text-red-500 text-xs mt-0.5">{formErrors.startDate}</p>
                      )}
                    </div>
                  </div>

                  {/* Duration and Operator */}
                  <div className="grid md:grid-cols-2 gap-4">
                    {/* Duration */}
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                        Durasi Sewa (Shift / Hari)
                      </label>
                      <input
                        type="number"
                        min="1"
                        max="90"
                        value={duration}
                        onChange={(e) => setDuration(Math.max(1, parseInt(e.target.value, 10) || 1))}
                        className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm bg-white text-slate-800 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                      />
                      <span className="text-[11px] text-slate-500 block mt-0.5">1 shift setara dengan 8 jam operasional</span>
                    </div>

                    {/* Operator Toggle */}
                    <div className="flex flex-col justify-center">
                      <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                        Layanan Operator
                      </label>
                      <label className="flex items-center gap-3 cursor-pointer bg-slate-50 border border-slate-200 p-2.5 rounded-lg select-none hover:bg-slate-100 transition-colors">
                        <input
                          type="checkbox"
                          checked={isOperatorNeeded}
                          onChange={(e) => setIsOperatorNeeded(e.target.checked)}
                          className="w-4.5 h-4.5 rounded text-secondary-container focus:ring-secondary-container border-slate-300"
                        />
                        <div className="text-xs">
                          <span className="font-bold text-slate-800 block">Termasuk Operator Bersertifikat</span>
                          <span className="text-slate-500">Saran K3: Sangat direkomendasikan (+Rp 500rb/shift)</span>
                        </div>
                      </label>
                    </div>
                  </div>

                  {/* Notes */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Catatan Tambahan / Detail Lokasi Proyek
                    </label>
                    <div className="relative">
                      <MessageSquare className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                      <textarea
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        placeholder="Contoh: Pengiriman ke area Cikarang Barat, proyek jalan semen kasar..."
                        rows={2}
                        className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg text-sm bg-white text-slate-800 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                      />
                    </div>
                  </div>

                  {/* Estimated Pricing Summary Card */}
                  <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
                    <div className="flex justify-between text-xs text-slate-500 font-semibold uppercase tracking-wider">
                      <span>Estimasi Rincian Biaya</span>
                      <span className="flex items-center gap-1"><Calculator className="w-3.5 h-3.5" /> Kalkulator Instan</span>
                    </div>
                    <hr className="border-slate-200" />
                    <div className="space-y-1 text-sm text-slate-700">
                      <div className="flex justify-between">
                        <span>Sewa {currentEquipment?.name} ({duration} Shift):</span>
                        <span>{currentEquipment ? formatRupiah((parseInt(currentEquipment.rentalPrice.replace(/[^0-9]/g, ''), 10) || 0) * duration) : '-'}</span>
                      </div>
                      {isOperatorNeeded && (
                        <div className="flex justify-between text-slate-600">
                          <span>Jasa Operator Bersertifikat ({duration} Shift):</span>
                          <span>{formatRupiah(500000 * duration)}</span>
                        </div>
                      )}
                      <hr className="border-slate-200/60" />
                      <div className="flex justify-between font-bold text-primary text-base pt-1">
                        <span>Total Perkiraan Biaya:</span>
                        <span className="text-secondary">{formatRupiah(getEstimatedPrice())}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-[10px] text-slate-500 mt-2 bg-white px-2.5 py-1.5 rounded-lg border border-slate-100">
                      <Shield className="w-3.5 h-3.5 text-secondary-container flex-shrink-0" />
                      <span>Estimasi belum termasuk Pajak PPN 11% & mobilisasi tronton ke lokasi proyek Anda.</span>
                    </div>
                  </div>

                  {/* Submit Button */}
                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full bg-secondary-container text-white py-3 rounded-lg font-display font-semibold hover:brightness-110 active:scale-98 transition-all flex items-center justify-center gap-2 shadow-md hover:shadow-lg"
                    >
                      Kirim Permintaan & Dapatkan Penawaran Resmi
                    </button>
                  </div>
                </form>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
