import React, { useState } from 'react';
import { EQUIPMENTS } from '../data';
import { Equipment, EquipmentCategory } from '../types';
import { Search, Anvil, Calendar, Settings, Compass, Info, Check, ShieldAlert, BadgeInfo, Eye } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface CatalogProps {
  onSewaClick: (equipment: Equipment) => void;
}

export default function Catalog({ onSewaClick }: CatalogProps) {
  const [selectedCategory, setSelectedCategory] = useState<EquipmentCategory>('Semua');
  const [searchQuery, setSearchQuery] = useState('');
  const [expanded, setExpanded] = useState(false);
  const [activeDetailId, setActiveDetailId] = useState<string | null>(null);

  const categories: EquipmentCategory[] = ['Semua', 'Excavator', 'Bulldozer', 'Crane', 'Dump Truck'];

  // Filter based on category and search query
  const filteredEquipments = EQUIPMENTS.filter((eq) => {
    const matchesCategory = selectedCategory === 'Semua' || eq.category === selectedCategory;
    const matchesSearch =
      eq.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      eq.model.toLowerCase().includes(searchQuery.toLowerCase()) ||
      eq.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Limit initially displayed items to 4, showing all if 'expanded' is true or if filtering
  const displayedEquipments =
    expanded || searchQuery || selectedCategory !== 'Semua'
      ? filteredEquipments
      : filteredEquipments.slice(0, 4);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Available':
        return 'bg-emerald-50 text-emerald-700 border border-emerald-200';
      case 'On Rent':
        return 'bg-blue-50 text-blue-700 border border-blue-200';
      case 'Maintenance':
        return 'bg-rose-50 text-rose-700 border border-rose-200';
      default:
        return 'bg-slate-50 text-slate-700 border border-slate-200';
    }
  };

  const getSpecIcon = (category: string) => {
    switch (category) {
      case 'Excavator':
        return <Anvil className="w-4 h-4 text-primary" />;
      case 'Bulldozer':
        return <Settings className="w-4 h-4 text-primary animate-spin-slow" />;
      case 'Crane':
        return <Compass className="w-4 h-4 text-primary" />;
      case 'Dump Truck':
        return <Settings className="w-4 h-4 text-primary" />;
      default:
        return <Settings className="w-4 h-4 text-primary" />;
    }
  };

  const getSpecLabel = (eq: Equipment) => {
    if (eq.specs.weight) return `Berat: ${eq.specs.weight}`;
    if (eq.specs.power) return `Daya: ${eq.specs.power}`;
    if (eq.specs.capacity) return `Kapasitas: ${eq.specs.capacity}`;
    return 'Spesifikasi Standar';
  };

  return (
    <section id="catalog" className="py-24 bg-slate-50 font-sans scroll-mt-20">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Heading */}
        <div className="text-center mb-12">
          <span className="text-secondary-container font-bold text-xs uppercase tracking-widest block mb-1">
            Daftar Armada Terbaik
          </span>
          <h2 className="font-display font-extrabold text-2xl md:text-4xl text-primary mb-4 leading-tight">
            Katalog Alat Berat
          </h2>
          <div className="w-24 h-1 bg-secondary-container mx-auto rounded-full" />
        </div>

        {/* Search & Category Filter bar */}
        <div className="max-w-4xl mx-auto mb-12 space-y-6">
          {/* Dynamic Search */}
          <div className="relative">
            <Search className="absolute left-4 top-3.5 w-5 h-5 text-slate-400" />
            <input
              type="text"
              placeholder="Cari armada (Contoh: Caterpillar, Bulldozer, 320D...)"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-11 pr-4 py-3.5 border border-slate-300 rounded-xl text-sm bg-white text-slate-800 placeholder-slate-400 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary shadow-xs transition-shadow"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-4 top-3 text-xs text-slate-400 hover:text-slate-600 bg-slate-100 hover:bg-slate-200 px-2 py-1 rounded"
              >
                Reset
              </button>
            )}
          </div>

          {/* Category Chip Buttons */}
          <div className="flex flex-wrap justify-center gap-2.5">
            {categories.map((cat) => {
              const isActive = selectedCategory === cat;
              return (
                <button
                  key={cat}
                  onClick={() => {
                    setSelectedCategory(cat);
                    setActiveDetailId(null);
                  }}
                  className={`px-5 py-2.5 rounded-full text-xs font-semibold tracking-wide transition-all shadow-xs ${
                    isActive
                      ? 'bg-primary text-white font-bold scale-102 border border-primary'
                      : 'bg-white hover:bg-slate-100 text-slate-600 border border-slate-200'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>
        </div>

        {/* Equipment Grid */}
        <motion.div layout className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          <AnimatePresence mode="popLayout">
            {displayedEquipments.map((eq) => {
              const isDetailOpen = activeDetailId === eq.id;

              return (
                <motion.div
                  key={eq.id}
                  layout
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.3 }}
                  className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-lg transition-all flex flex-col h-full group"
                >
                  {/* Image wrapper */}
                  <div className="relative h-48 overflow-hidden bg-slate-100 flex-shrink-0">
                    <img
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      alt={eq.name}
                      src={eq.image}
                      referrerPolicy="no-referrer"
                    />
                    {/* Status Badge */}
                    <div className="absolute top-4 left-4">
                      <span className={`text-[10px] font-extrabold px-3 py-1 rounded-full uppercase tracking-wider ${getStatusColor(eq.status)}`}>
                        {eq.status === 'Available' ? 'Tersedia' : eq.status === 'On Rent' ? 'Sedang Disewa' : 'Pemeliharaan'}
                      </span>
                    </div>
                    {/* Pricing badge */}
                    <div className="absolute bottom-2 right-2 bg-slate-900/80 text-white font-sans font-semibold text-[11px] px-2.5 py-1 rounded-md">
                      {eq.rentalPrice.split(' / ')[0]}
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                    <div className="space-y-2">
                      <div>
                        <h3 className="font-display font-extrabold text-slate-800 text-base leading-tight">
                          {eq.name}
                        </h3>
                        <p className="text-slate-500 text-xs font-medium font-sans mt-0.5">
                          {eq.model}
                        </p>
                      </div>

                      {/* Specs pills */}
                      <div className="grid grid-cols-2 gap-2 pt-1">
                        <div className="flex items-center gap-1.5 text-xs text-slate-600 font-medium">
                          {getSpecIcon(eq.category)}
                          <span className="truncate">{getSpecLabel(eq)}</span>
                        </div>
                        <div className="flex items-center gap-1.5 text-xs text-slate-600 font-medium">
                          <Calendar className="w-4 h-4 text-primary" />
                          <span>Tahun: {eq.specs.year}</span>
                        </div>
                      </div>
                    </div>

                    {/* Expandable details view */}
                    <AnimatePresence>
                      {isDetailOpen && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          exit={{ opacity: 0, height: 0 }}
                          className="bg-slate-50 rounded-lg p-3 text-xs text-slate-600 space-y-2 border border-slate-200 overflow-hidden"
                        >
                          <p className="italic text-slate-500 font-sans leading-relaxed">
                            &ldquo;{eq.description}&rdquo;
                          </p>
                          <hr className="border-slate-200" />
                          <div className="space-y-1">
                            <span className="font-bold text-[10px] text-primary uppercase tracking-wider block">Fitur Unggulan:</span>
                            {eq.features.map((feat) => (
                              <div key={feat} className="flex items-start gap-1">
                                <Check className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0 mt-0.5" />
                                <span>{feat}</span>
                              </div>
                            ))}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>

                    {/* Action buttons */}
                    <div className="flex gap-2 pt-1 flex-shrink-0">
                      <button
                        onClick={() => onSewaClick(eq)}
                        className="flex-1 bg-primary hover:bg-primary/95 text-white py-2 rounded-lg text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1 hover:brightness-105 active:scale-98"
                      >
                        Sewa Sekarang
                      </button>
                      <button
                        onClick={() => setActiveDetailId(isDetailOpen ? null : eq.id)}
                        className={`px-3 border rounded-lg hover:bg-slate-100 transition-colors flex items-center justify-center ${
                          isDetailOpen ? 'border-primary bg-primary/5 text-primary' : 'border-slate-300 text-slate-600'
                        }`}
                        title="Detail Fitur Alat"
                      >
                        <Info className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </motion.div>

        {/* Empty State */}
        {filteredEquipments.length === 0 && (
          <div className="text-center py-16 bg-white rounded-xl border border-dashed border-slate-300 max-w-md mx-auto mt-6">
            <BadgeInfo className="w-12 h-12 text-slate-400 mx-auto mb-2" />
            <p className="text-slate-600 font-bold">Armada tidak ditemukan</p>
            <p className="text-slate-500 text-xs mt-1">Coba sesuaikan kata kunci pencarian atau kategori filter Anda.</p>
          </div>
        )}

        {/* Show More toggle link */}
        {!searchQuery && selectedCategory === 'Semua' && filteredEquipments.length > 4 && (
          <div className="mt-12 text-center">
            <button
              onClick={() => setExpanded(!expanded)}
              className="inline-flex items-center gap-2 font-display font-bold text-xs text-primary hover:text-secondary-container transition-all group bg-white px-6 py-3.5 rounded-full border border-slate-200 shadow-xs hover:shadow-md"
            >
              <span>{expanded ? 'Sembunyikan Katalog' : 'Lihat Katalog Selengkapnya'}</span>
              <motion.span
                animate={{ rotate: expanded ? 180 : 0 }}
                transition={{ duration: 0.3 }}
              >
                ↓
              </motion.span>
            </button>
          </div>
        )}
      </div>
    </section>
  );
}
