import React, { useState } from 'react';
import { Inquiry } from '../types';
import { Mail, Phone, Calendar, Clock, CheckCircle2, XCircle, Search, Trash2, SlidersHorizontal, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface AdminInboxProps {
  inquiries: Inquiry[];
  onUpdateStatus: (id: string, status: 'Pending' | 'Approved' | 'Rejected') => void;
  onDeleteInquiry: (id: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

export default function AdminInbox({
  inquiries,
  onUpdateStatus,
  onDeleteInquiry,
  isOpen,
  onClose
}: AdminInboxProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Pending' | 'Approved' | 'Rejected'>('All');

  const filteredInquiries = inquiries.filter((inq) => {
    const matchesSearch =
      inq.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inq.equipmentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inq.customerEmail.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'All' || inq.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex justify-end">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/50 backdrop-blur-xs"
          />

          {/* Sliding Inbox Panel */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="relative w-full max-w-lg h-full bg-slate-50 border-l border-slate-200 shadow-2xl flex flex-col z-10"
          >
            {/* Header */}
            <div className="bg-primary text-white p-5 flex justify-between items-center">
              <div>
                <h3 className="font-display font-semibold text-lg text-white flex items-center gap-2">
                  <span className="w-2.5 h-2.5 bg-secondary rounded-full animate-pulse" />
                  Kotak Masuk Penawaran (Admin / User)
                </h3>
                <p className="text-xs text-white/80 font-sans">
                  Pantau & kelola pengajuan quotation penyewaan alat berat Anda
                </p>
              </div>
              <button
                onClick={onClose}
                className="text-white/80 hover:text-white hover:bg-white/10 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors"
              >
                Tutup Panel
              </button>
            </div>

            {/* Quick Status Bar */}
            <div className="bg-slate-100 border-b border-slate-200 p-4 space-y-3 font-sans">
              <div className="flex gap-2 items-center text-xs text-slate-500 font-bold uppercase tracking-wider">
                <SlidersHorizontal className="w-3.5 h-3.5" /> Filter & Pencarian
              </div>
              <div className="relative">
                <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  placeholder="Cari nama, email, atau unit..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg text-sm bg-white text-slate-800 focus:outline-none focus:border-primary"
                />
              </div>

              {/* Filter Tabs */}
              <div className="flex gap-1 bg-slate-200 p-1 rounded-lg text-xs">
                {['All', 'Pending', 'Approved', 'Rejected'].map((status) => {
                  const isActive = statusFilter === status;
                  return (
                    <button
                      key={status}
                      onClick={() => setStatusFilter(status as any)}
                      className={`flex-1 py-1.5 rounded-md font-medium transition-all ${
                        isActive ? 'bg-white text-primary shadow-xs font-bold' : 'text-slate-600 hover:text-slate-800'
                      }`}
                    >
                      {status === 'All' ? 'Semua' : status === 'Pending' ? 'Tertunda' : status === 'Approved' ? 'Disetujui' : 'Ditolak'}
                      <span className="ml-1 bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded-full text-[10px]">
                        {status === 'All'
                          ? inquiries.length
                          : inquiries.filter((i) => i.status === status).length}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Inquiries List */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 font-sans">
              {filteredInquiries.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-20 text-center text-slate-400">
                  <Info className="w-12 h-12 text-slate-300 mb-2" />
                  <p className="text-sm font-semibold">Tidak Ada Pengajuan Ditemukan</p>
                  <p className="text-xs max-w-xs mt-1">
                    Silakan buka formulir penawaran di landing page untuk membuat pengajuan sewa baru.
                  </p>
                </div>
              ) : (
                filteredInquiries.map((inq) => (
                  <motion.div
                    key={inq.id}
                    layout
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow relative overflow-hidden"
                  >
                    {/* Status accent side bar */}
                    <div
                      className={`absolute left-0 top-0 bottom-0 w-1.5 ${
                        inq.status === 'Approved'
                          ? 'bg-emerald-500'
                          : inq.status === 'Rejected'
                          ? 'bg-rose-500'
                          : 'bg-amber-400'
                      }`}
                    />

                    {/* Card Content */}
                    <div className="pl-2">
                      <div className="flex justify-between items-start gap-2 mb-2">
                        <div>
                          <span className="text-[10px] bg-primary/10 text-primary font-bold px-2 py-0.5 rounded-full">
                            ID: {inq.id}
                          </span>
                          <h4 className="font-display font-bold text-slate-900 mt-1">{inq.customerName}</h4>
                          <span className="text-xs text-slate-500 font-medium">{inq.customerEmail}</span>
                        </div>
                        
                        {/* Status Label */}
                        <span
                          className={`text-xs font-bold px-2.5 py-1 rounded-full ${
                            inq.status === 'Approved'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                              : inq.status === 'Rejected'
                              ? 'bg-rose-50 text-rose-700 border border-rose-100'
                              : 'bg-amber-50 text-amber-700 border border-amber-100'
                          }`}
                        >
                          {inq.status === 'Approved' ? 'Disetujui' : inq.status === 'Rejected' ? 'Ditolak' : 'Tertunda'}
                        </span>
                      </div>

                      {/* Equipment detail */}
                      <div className="bg-slate-50 rounded-lg p-2.5 text-xs text-slate-700 space-y-1 border border-slate-100 mb-3">
                        <div className="flex justify-between">
                          <span className="text-slate-500">Unit Diminta:</span>
                          <strong className="text-slate-800">{inq.equipmentName}</strong>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Durasi Sewa:</span>
                          <strong className="text-slate-800">{inq.duration} Shift (Hari)</strong>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Mulai Kerja:</span>
                          <span className="font-medium text-slate-800">{inq.startDate}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Operator K3:</span>
                          <span className="font-medium text-slate-800">
                            {inq.isOperatorNeeded ? 'Ya (Termasuk)' : 'Tidak (Lepas Kunci)'}
                          </span>
                        </div>
                        {inq.notes && (
                          <div className="mt-1 pt-1 border-t border-slate-200/60 text-[11px] text-slate-500 italic">
                            &ldquo;{inq.notes}&rdquo;
                          </div>
                        )}
                      </div>

                      {/* Client Contacts */}
                      <div className="flex items-center gap-3 text-xs text-slate-500 border-t border-slate-100 pt-3 mb-3">
                        <span className="flex items-center gap-1">
                          <Phone className="w-3.5 h-3.5 text-slate-400" /> {inq.customerPhone}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-slate-400" /> {new Date(inq.createdAt).toLocaleDateString('id-ID', { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>

                      {/* Actions */}
                      <div className="flex gap-2 justify-between items-center">
                        <div className="flex gap-1.5">
                          {inq.status !== 'Approved' && (
                            <button
                              onClick={() => onUpdateStatus(inq.id, 'Approved')}
                              className="bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 text-xs px-2.5 py-1.5 rounded-lg flex items-center gap-1 font-semibold transition-colors"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" /> Setujui
                            </button>
                          )}
                          {inq.status !== 'Rejected' && (
                            <button
                              onClick={() => onUpdateStatus(inq.id, 'Rejected')}
                              className="bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 text-xs px-2.5 py-1.5 rounded-lg flex items-center gap-1 font-semibold transition-colors"
                            >
                              <XCircle className="w-3.5 h-3.5" /> Tolak
                            </button>
                          )}
                        </div>

                        <button
                          onClick={() => onDeleteInquiry(inq.id)}
                          className="text-slate-400 hover:text-rose-600 p-1.5 rounded-lg hover:bg-rose-50 transition-colors"
                          title="Hapus"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </motion.div>
                ))
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
