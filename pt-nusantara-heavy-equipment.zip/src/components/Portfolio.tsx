import React, { useState } from 'react';
import { PROJECTS } from '../data';
import { ChevronLeft, ChevronRight, MapPin, Hammer, CalendarRange, ArrowUpRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function Portfolio() {
  const [activeProjectIdx, setActiveProjectIdx] = useState(0);

  const handlePrev = () => {
    setActiveProjectIdx((prev) => (prev === 0 ? PROJECTS.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setActiveProjectIdx((prev) => (prev === PROJECTS.length - 1 ? 0 : prev + 1));
  };

  return (
    <section id="projects" className="py-24 bg-slate-100 font-sans scroll-mt-20">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header bar with controls */}
        <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
          <div>
            <span className="text-secondary-container font-bold text-xs uppercase tracking-widest block mb-1">
              Rekam Jejak Nyata
            </span>
            <h2 className="font-display font-extrabold text-2xl md:text-4xl text-primary mb-3">
              Portfolio Proyek
            </h2>
            <p className="text-slate-500 text-sm md:text-base max-w-xl">
              Kontribusi aktif kami dalam penyediaan armada prima untuk mensukseskan pembangunan berbagai infrastruktur vital nasional.
            </p>
          </div>

          {/* Carousel Slider Controls */}
          <div className="flex gap-3">
            <button
              onClick={handlePrev}
              className="bg-white hover:bg-primary hover:text-white text-slate-700 p-3.5 rounded-full border border-slate-200 transition-all shadow-xs"
              title="Sebelumnya"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={handleNext}
              className="bg-white hover:bg-primary hover:text-white text-slate-700 p-3.5 rounded-full border border-slate-200 transition-all shadow-xs"
              title="Selanjutnya"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Featured Project Showcase */}
        <div className="mb-12 bg-white rounded-2xl overflow-hidden border border-slate-200 shadow-md grid md:grid-cols-12">
          {/* Visual Left */}
          <div className="md:col-span-7 relative overflow-hidden min-h-[300px] md:h-[450px]">
            <AnimatePresence mode="wait">
              <motion.img
                key={activeProjectIdx}
                initial={{ opacity: 0.6, scale: 1.05 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0.6 }}
                transition={{ duration: 0.4 }}
                src={PROJECTS[activeProjectIdx].image}
                alt={PROJECTS[activeProjectIdx].title}
                className="absolute inset-0 w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </AnimatePresence>
            <div className="absolute top-4 left-4">
              <span className="bg-primary/90 text-white font-display font-extrabold text-[10px] px-3 py-1.5 rounded-full uppercase tracking-widest shadow-sm">
                {PROJECTS[activeProjectIdx].category}
              </span>
            </div>
          </div>

          {/* Details Right */}
          <div className="md:col-span-5 p-8 md:p-10 flex flex-col justify-between bg-white">
            <div className="space-y-6">
              <div className="space-y-2">
                <span className="text-secondary font-semibold text-xs uppercase tracking-wider block">
                  Proyek Unggulan
                </span>
                <h3 className="font-display font-extrabold text-slate-800 text-xl md:text-2xl leading-tight">
                  {PROJECTS[activeProjectIdx].title}
                </h3>
              </div>

              <p className="text-slate-600 text-sm leading-relaxed font-sans">
                {PROJECTS[activeProjectIdx].description}
              </p>

              {/* Specification Specs List */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center gap-3 text-slate-700 text-xs">
                  <MapPin className="w-4.5 h-4.5 text-secondary flex-shrink-0" />
                  <span>
                    Lokasi: <strong>{PROJECTS[activeProjectIdx].location}</strong>
                  </span>
                </div>
                <div className="flex items-center gap-3 text-slate-700 text-xs">
                  <CalendarRange className="w-4.5 h-4.5 text-secondary flex-shrink-0" />
                  <span>
                    Tahun Pengerjaan: <strong>{PROJECTS[activeProjectIdx].year}</strong>
                  </span>
                </div>
                <div className="flex items-start gap-3 text-slate-700 text-xs">
                  <Hammer className="w-4.5 h-4.5 text-secondary flex-shrink-0 mt-0.5" />
                  <div>
                    <span className="block mb-1 font-semibold text-slate-500">Unit Digunakan:</span>
                    <div className="flex flex-wrap gap-1.5">
                      {PROJECTS[activeProjectIdx].equipmentUsed.map((eq) => (
                        <span
                          key={eq}
                          className="bg-slate-100 border border-slate-200 text-slate-700 font-bold px-2 py-0.5 rounded text-[10px]"
                        >
                          {eq}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Selection indicators */}
            <div className="flex items-center justify-between border-t border-slate-150 pt-6 mt-8">
              <div className="flex gap-2">
                {PROJECTS.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveProjectIdx(idx)}
                    className={`h-2.5 rounded-full transition-all duration-300 ${
                      idx === activeProjectIdx ? 'w-8 bg-secondary' : 'w-2.5 bg-slate-300'
                    }`}
                    title={`Pindah ke Proyek ${idx + 1}`}
                  />
                ))}
              </div>
              <span className="text-slate-400 font-bold text-xs tracking-wider">
                0{activeProjectIdx + 1} / 0{PROJECTS.length}
              </span>
            </div>
          </div>
        </div>

        {/* Dynamic Static Cards underneath for desktop list */}
        <div className="grid md:grid-cols-3 gap-6">
          {PROJECTS.map((proj, idx) => {
            const isCurrent = idx === activeProjectIdx;
            return (
              <div
                key={proj.id}
                onClick={() => setActiveProjectIdx(idx)}
                className={`group cursor-pointer relative overflow-hidden rounded-xl aspect-16/10 border transition-all duration-300 ${
                  isCurrent
                    ? 'ring-2 ring-secondary border-transparent scale-102 shadow-lg'
                    : 'border-slate-200 shadow-xs hover:shadow-md'
                }`}
              >
                <img
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  src={proj.image}
                  alt={proj.title}
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-primary/95 via-primary/50 to-transparent flex flex-col justify-end p-5" />
                <div className="absolute bottom-4 left-4 right-4 text-white">
                  <span className="text-secondary-container font-bold text-[9px] uppercase tracking-widest block mb-1">
                    {proj.category}
                  </span>
                  <h4 className="font-display font-bold text-sm text-white group-hover:text-secondary-container transition-colors truncate">
                    {proj.title}
                  </h4>
                </div>
                <div className="absolute top-4 right-4 bg-white/20 backdrop-blur-xs p-1.5 rounded-full text-white opacity-0 group-hover:opacity-100 transition-opacity">
                  <ArrowUpRight className="w-4 h-4" />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
