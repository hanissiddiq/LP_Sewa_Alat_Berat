import React from 'react';
import { WHY_CHOOSE_US } from '../data';
import { Wrench, Award, Banknote, Headphones, Globe2, ShieldCheck } from 'lucide-react';
import { motion } from 'motion/react';

export default function WhyChooseUs() {
  const getIcon = (name: string) => {
    switch (name) {
      case 'engineering':
        return <Wrench className="w-10 h-10 text-secondary-container" />;
      case 'badge':
        return <Award className="w-10 h-10 text-secondary-container" />;
      case 'payments':
        return <Banknote className="w-10 h-10 text-secondary-container" />;
      case 'support_agent':
        return <Headphones className="w-10 h-10 text-secondary-container" />;
      case 'public':
        return <Globe2 className="w-10 h-10 text-secondary-container" />;
      case 'health_and_safety':
        return <ShieldCheck className="w-10 h-10 text-secondary-container" />;
      default:
        return <Wrench className="w-10 h-10 text-secondary-container" />;
    }
  };

  return (
    <section className="py-24 bg-primary text-white relative overflow-hidden font-sans">
      {/* Absolute "TRUST" Watermark Decoration */}
      <div className="absolute right-[-40px] top-[10%] opacity-[0.03] pointer-events-none select-none z-0">
        <span
          className="font-display font-black tracking-widest text-white leading-none block"
          style={{ fontSize: '320px', letterSpacing: '0.05em' }}
        >
          TRUST
        </span>
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        {/* Header */}
        <div className="mb-16 max-w-2xl">
          <span className="text-secondary-container font-bold text-xs uppercase tracking-widest block mb-1">
            Keunggulan Utama Kami
          </span>
          <h2 className="font-display font-extrabold text-2xl md:text-4xl text-white mb-4 leading-tight">
            Mengapa Memilih Kami
          </h2>
          <p className="text-slate-300 text-sm md:text-base leading-relaxed opacity-90">
            Kami memberikan lebih dari sekadar penyediaan unit alat berat; kami memberikan komitmen, kepastian operasional, 
            dan mitigasi resiko maksimal bagi kelancaran proyek Anda.
          </p>
        </div>

        {/* 6-Grid Value Cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {WHY_CHOOSE_US.map((item, i) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="p-8 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10 hover:border-white/20 transition-all duration-300 group flex flex-col justify-between h-full"
            >
              <div className="space-y-5">
                <div className="group-hover:scale-110 transition-transform duration-300 w-fit">
                  {getIcon(item.iconName)}
                </div>
                <div className="space-y-2">
                  <h3 className="font-display font-bold text-lg text-white group-hover:text-secondary-container transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-slate-300 text-xs md:text-sm leading-relaxed opacity-85">
                    {item.description}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
