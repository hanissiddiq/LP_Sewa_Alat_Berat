import React from 'react';
import { MapPin, Phone, Mail, Hammer, Award } from 'lucide-react';

export default function Footer() {
  const quickLinks = [
    { name: 'Home', href: '#' },
    { name: 'About Us', href: '#about' },
    { name: 'Equipment Catalog', href: '#catalog' },
    { name: 'Project Portfolio', href: '#projects' }
  ];

  const legalLinks = [
    { name: 'Privacy Policy', href: '#' },
    { name: 'Terms of Service', href: '#' },
    { name: 'Sitemap', href: '#' }
  ];

  return (
    <footer className="bg-primary text-white pt-16 pb-8 border-t border-primary-container/40 font-sans">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-10">
        {/* Identity block */}
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-secondary-container flex items-center justify-center text-primary">
              <Hammer className="w-5 h-5 text-primary" />
            </div>
            <span className="text-lg font-display font-black tracking-tight text-white uppercase">
              PT Nusantara
            </span>
          </div>
          <p className="text-slate-300 text-xs leading-relaxed max-w-xs font-normal">
            Penyedia jasa penyewaan alat berat terpercaya di seluruh Indonesia dengan komitmen kuat pada mutu prima, 
            presisi kerja, dan keselamatan kerja (K3).
          </p>
          <div className="flex items-center gap-2 pt-2 text-emerald-400 text-xs font-semibold">
            <Award className="w-4.5 h-4.5 text-emerald-400" />
            <span>ISO 45001 Safety Certified</span>
          </div>
        </div>

        {/* Quick Links Column */}
        <div className="space-y-4">
          <h4 className="text-secondary-container font-display font-bold text-sm uppercase tracking-wider">
            Quick Links
          </h4>
          <ul className="space-y-2.5">
            {quickLinks.map((link) => (
              <li key={link.name}>
                <a
                  href={link.href}
                  className="text-slate-300 hover:text-secondary-container text-xs transition-colors font-medium"
                >
                  {link.name}
                </a>
              </li>
            ))}
          </ul>
        </div>

        {/* Legal Column */}
        <div className="space-y-4">
          <h4 className="text-secondary-container font-display font-bold text-sm uppercase tracking-wider">
            Legal
          </h4>
          <ul className="space-y-2.5">
            {legalLinks.map((link) => (
              <li key={link.name}>
                <a
                  href={link.href}
                  className="text-slate-300 hover:text-secondary-container text-xs transition-colors font-medium"
                >
                  {link.name}
                </a>
              </li>
            ))}
          </ul>
        </div>

        {/* Contact Info Column */}
        <div className="space-y-4">
          <h4 className="text-secondary-container font-display font-bold text-sm uppercase tracking-wider">
            Contact Info
          </h4>
          <ul className="space-y-3 text-xs text-slate-300">
            <li className="flex items-start gap-2.5 leading-relaxed">
              <MapPin className="w-4.5 h-4.5 text-secondary-container flex-shrink-0 mt-0.5" />
              <span>Kawasan Industri Jababeka, Cikarang, Jawa Barat, Indonesia</span>
            </li>
            <li className="flex items-center gap-2.5">
              <Phone className="w-4.5 h-4.5 text-secondary-container flex-shrink-0" />
              <span>+62 21 888 9999</span>
            </li>
            <li className="flex items-center gap-2.5">
              <Mail className="w-4.5 h-4.5 text-secondary-container flex-shrink-0" />
              <a href="mailto:info@pt-nusantara.co.id" className="hover:text-secondary-container transition-colors">
                info@pt-nusantara.co.id
              </a>
            </li>
          </ul>
        </div>
      </div>

      {/* Copyright Divider */}
      <div className="max-w-7xl mx-auto px-6 mt-12 pt-8 border-t border-white/10 text-center">
        <p className="text-slate-400 text-xs font-medium font-sans">
          © {new Date().getFullYear()} PT Nusantara Heavy Equipment. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
