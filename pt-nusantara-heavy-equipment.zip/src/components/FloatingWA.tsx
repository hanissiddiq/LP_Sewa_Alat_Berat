import React, { useState } from 'react';
import { MessageSquarePlus } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function FloatingWA() {
  const [showTooltip, setShowTooltip] = useState(false);
  const waUrl = 'https://wa.me/628123456789?text=Halo%20PT%20Nusantara,%20saya%2520ingin%2520bertanya%2520tentang%2520penyewaan%252520alat%252520berat%252520untuk%252520proyek%252520saya.';

  return (
    <div className="fixed bottom-8 right-8 z-50 font-sans flex items-center">
      {/* Tooltip on Hover */}
      <AnimatePresence>
        {showTooltip && (
          <motion.div
            initial={{ opacity: 0, x: 20, scale: 0.9 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 20, scale: 0.9 }}
            className="absolute right-full mr-4 bg-white text-slate-800 border border-slate-200 px-4 py-2.5 rounded-xl shadow-xl text-xs font-bold whitespace-nowrap pointer-events-none hidden md:block"
          >
            <span className="text-primary font-bold">Butuh bantuan?</span> Chat WhatsApp kami
          </motion.div>
        )}
      </AnimatePresence>

      {/* WhatsApp Button */}
      <a
        href={waUrl}
        target="_blank"
        rel="noopener noreferrer"
        onMouseEnter={() => setShowTooltip(true)}
        onMouseLeave={() => setShowTooltip(false)}
        className="bg-[#25D366] text-white p-4 rounded-full shadow-2xl hover:scale-110 active:scale-95 transition-transform flex items-center justify-center border-2 border-white/40"
        title="WhatsApp Live Chat"
      >
        <MessageSquarePlus className="w-6 h-6 text-white" />
      </a>
    </div>
  );
}
