import React, { useState } from 'react';
import { FAQS } from '../data';
import { ChevronDown, HelpCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function FAQ() {
  const [openId, setOpenId] = useState<string | null>('faq-1');

  const toggleFAQ = (id: string) => {
    setOpenId(openId === id ? null : id);
  };

  return (
    <section id="faq" className="py-24 bg-slate-50 font-sans scroll-mt-20">
      <div className="max-w-4xl mx-auto px-6">
        {/* Section Heading */}
        <div className="text-center mb-16">
          <span className="text-secondary-container font-bold text-xs uppercase tracking-widest block mb-1">
            Ada Pertanyaan?
          </span>
          <h2 className="font-display font-extrabold text-2xl md:text-4xl text-primary mb-4 leading-tight">
            Pertanyaan Umum (FAQ)
          </h2>
          <div className="w-24 h-1 bg-secondary-container mx-auto rounded-full" />
        </div>

        {/* FAQ Accordion List */}
        <div className="space-y-4">
          {FAQS.map((faq) => {
            const isOpen = openId === faq.id;

            return (
              <div
                key={faq.id}
                className={`bg-white rounded-xl border transition-all duration-300 overflow-hidden ${
                  isOpen
                    ? 'border-primary/40 shadow-md ring-1 ring-primary/10'
                    : 'border-slate-200 hover:border-slate-300 shadow-xs'
                }`}
              >
                {/* Accordion Trigger Header */}
                <button
                  onClick={() => toggleFAQ(faq.id)}
                  className="w-full flex justify-between items-center p-6 text-left hover:bg-slate-50/50 transition-colors font-sans focus:outline-none select-none group"
                >
                  <span className="flex items-center gap-3">
                    <HelpCircle className={`w-5 h-5 flex-shrink-0 transition-colors ${
                      isOpen ? 'text-secondary-container' : 'text-slate-400'
                    }`} />
                    <span className="font-display font-bold text-primary text-sm md:text-base group-hover:text-primary-container transition-colors">
                      {faq.question}
                    </span>
                  </span>
                  <motion.div
                    animate={{ rotate: isOpen ? 180 : 0 }}
                    transition={{ duration: 0.25 }}
                    className={`p-1 rounded-full ${
                      isOpen ? 'bg-primary/5 text-primary' : 'text-slate-400 group-hover:text-slate-600'
                    }`}
                  >
                    <ChevronDown className="w-5 h-5" />
                  </motion.div>
                </button>

                {/* Collapsible content wrapper */}
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3, ease: 'easeInOut' }}
                    >
                      <div className="px-6 pb-6 pt-1 text-slate-600 text-xs md:text-sm leading-relaxed border-t border-slate-100 bg-slate-50/40">
                        <p className="font-normal">{faq.answer}</p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
