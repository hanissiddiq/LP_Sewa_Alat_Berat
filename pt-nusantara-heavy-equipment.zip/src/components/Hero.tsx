import React from 'react';
import { HERO_BG_IMAGE } from '../data';
import { ArrowDown, Flame, Award, Wrench, ShieldAlert } from 'lucide-react';
import { motion } from 'motion/react';

interface HeroProps {
  onMintaPenawaranClick: () => void;
}

export default function Hero({ onMintaPenawaranClick }: HeroProps) {
  const stats = [
    { value: '15+', label: 'Tahun Pengalaman' },
    { value: '250+', label: 'Unit Alat Berat' },
    { value: '500+', label: 'Proyek Selesai' },
    { value: '24/7', label: 'Support Teknis' }
  ];

  return (
    <section className="relative w-full min-h-[90vh] md:h-screen flex items-center pt-24 pb-40 overflow-hidden text-white font-sans bg-primary">
      {/* Background with Dark Overlay */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/95 via-primary/80 to-transparent z-10" />
        <div className="absolute inset-0 bg-primary/40 mix-blend-multiply z-10" />
        <img
          alt="Latar Belakang Alat Berat Konstruksi Nusantara"
          className="w-full h-full object-cover scale-105 animate-pulse/20"
          src={HERO_BG_IMAGE}
          style={{ animationDuration: '8s' }}
          referrerPolicy="no-referrer"
        />
      </div>

      {/* Hero Content */}
      <div className="relative z-20 max-w-7xl mx-auto px-6 w-full pt-12 md:pt-20">
        <div className="max-w-3xl space-y-6">
          {/* Accent Chip */}
          <motion.div
            initial={{ opacity: 0, y: -15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-secondary-container/20 border border-secondary-container/40 text-secondary-container text-xs font-bold uppercase tracking-wider"
          >
            <Flame className="w-4.5 h-4.5 text-secondary-container fill-secondary-container" />
            <span>Penyewaan Alat Berat Terpercaya #1</span>
          </motion.div>

          {/* Main Title */}
          <motion.h1
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="font-display font-extrabold text-3xl md:text-5xl lg:text-6xl text-white leading-tight md:leading-[1.1] tracking-tight"
          >
            Solusi Sewa Alat Berat <br />
            <span className="text-secondary-container relative">
              Profesional
              <span className="absolute left-0 bottom-1 w-full h-1 bg-secondary-container/80 rounded-full" />
            </span>{' '}
            untuk Proyek Anda
          </motion.h1>

          {/* Description */}
          <motion.p
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-slate-300 font-sans text-sm md:text-lg max-w-2xl leading-relaxed font-normal"
          >
            Menyediakan berbagai alat berat berkualitas dengan operator berpengalaman untuk kebutuhan konstruksi,
            pertambangan, dan perkebunan di seluruh Indonesia.
          </motion.p>

          {/* Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-wrap gap-4 pt-4"
          >
            <button
              onClick={onMintaPenawaranClick}
              className="bg-secondary-container hover:brightness-110 active:scale-95 text-primary font-display font-extrabold text-sm px-8 py-4 rounded-lg transition-all shadow-lg hover:shadow-xl"
            >
              Minta Penawaran
            </button>
            <a
              href="#contact"
              className="border-2 border-slate-300 text-slate-200 hover:text-white hover:bg-white/10 hover:border-white px-8 py-3.5 rounded-lg text-sm font-bold font-display transition-all flex items-center justify-center gap-2"
            >
              Hubungi Kami <ArrowDown className="w-4 h-4 animate-bounce" />
            </a>
          </motion.div>
        </div>
      </div>

      {/* Glassmorphic Stats Bar */}
      <div className="absolute bottom-0 left-0 right-0 z-20 bg-slate-900/85 backdrop-blur-md border-t border-white/10 py-6 md:py-8 shadow-2xl">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 + i * 0.1 }}
              className="space-y-1 group"
            >
              <div className="font-display font-black text-2xl md:text-4xl text-secondary-container group-hover:scale-105 transition-transform duration-300">
                {stat.value}
              </div>
              <div className="text-[10px] md:text-xs font-bold text-slate-400 uppercase tracking-widest font-sans">
                {stat.label}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
