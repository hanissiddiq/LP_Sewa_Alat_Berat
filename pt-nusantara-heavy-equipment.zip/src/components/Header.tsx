import React, { useState, useEffect } from 'react';
import { Menu, X, Hammer, FileText, Inbox } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface HeaderProps {
  onRequestQuoteClick: () => void;
  onInboxClick: () => void;
  inquiryCount: number;
}

export default function Header({ onRequestQuoteClick, onInboxClick, inquiryCount }: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#' },
    { name: 'About', href: '#about' },
    { name: 'Catalog', href: '#catalog' },
    { name: 'Projects', href: '#projects' },
    { name: 'FAQ', href: '#faq' },
    { name: 'Contact', href: '#contact' }
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled
          ? 'bg-primary/95 shadow-lg backdrop-blur-md py-3.5 border-b border-primary-container/40'
          : 'bg-primary/80 backdrop-blur-xs py-5 border-b border-white/10'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        {/* Brand Logo */}
        <a href="#" className="flex items-center gap-2 group">
          <div className="w-10 h-10 rounded-lg bg-secondary-container flex items-center justify-center text-on-secondary-container shadow-md group-hover:rotate-6 transition-transform">
            <Hammer className="w-5.5 h-5.5 text-primary" />
          </div>
          <div className="flex flex-col">
            <span className="font-display font-extrabold text-lg text-white leading-tight tracking-tight uppercase">
              PT Nusantara
            </span>
            <span className="text-[9px] font-sans tracking-widest text-slate-300 font-bold -mt-0.5 uppercase">
              Heavy Equipment
            </span>
          </div>
        </a>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="text-slate-200 hover:text-secondary-container text-sm font-semibold transition-colors relative group py-1"
            >
              {link.name}
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-secondary-container transition-all group-hover:w-full" />
            </a>
          ))}
        </nav>

        {/* Action Button & Admin Inbox Badge */}
        <div className="hidden md:flex items-center gap-3">
          {/* Admin Inbox Toggle Button */}
          <button
            onClick={onInboxClick}
            className="relative p-2 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
            title="Lihat Kotak Masuk Pengajuan"
          >
            <Inbox className="w-5.5 h-5.5" />
            {inquiryCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-secondary-container text-primary font-extrabold text-[10px] w-5 h-5 rounded-full flex items-center justify-center border-2 border-primary animate-bounce">
                {inquiryCount}
              </span>
            )}
          </button>

          <button
            onClick={onRequestQuoteClick}
            className="bg-secondary-container hover:brightness-110 active:scale-95 text-primary font-display font-bold text-xs px-5 py-2.5 rounded-lg transition-all shadow-md hover:shadow-lg"
          >
            Request Quote
          </button>
        </div>

        {/* Mobile Hamburger Menu Toggle */}
        <div className="flex items-center gap-3 md:hidden">
          {/* Mobile Admin Inbox Trigger */}
          <button
            onClick={onInboxClick}
            className="relative p-2 rounded-lg text-slate-300 hover:text-white"
            title="Lihat Kotak Masuk"
          >
            <Inbox className="w-5.5 h-5.5" />
            {inquiryCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-secondary-container text-primary font-extrabold text-[9px] w-4.5 h-4.5 rounded-full flex items-center justify-center border-2 border-primary">
                {inquiryCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="text-slate-200 hover:text-white focus:outline-none p-1.5 rounded-lg hover:bg-white/10"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Panel */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-primary border-t border-primary-container/40 overflow-hidden"
          >
            <div className="px-6 py-4 space-y-3.5 flex flex-col">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="text-slate-200 hover:text-secondary-container text-sm font-semibold transition-colors py-1 block border-b border-white/5"
                >
                  {link.name}
                </a>
              ))}
              <div className="pt-2 flex flex-col gap-2">
                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    onRequestQuoteClick();
                  }}
                  className="w-full text-center bg-secondary-container hover:bg-secondary-container/90 text-primary font-display font-bold text-xs py-3 rounded-lg transition-colors"
                >
                  Request Quote
                </button>
                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    onInboxClick();
                  }}
                  className="w-full text-center border border-white/20 hover:bg-white/10 text-white font-sans font-medium text-xs py-3 rounded-lg transition-colors flex items-center justify-center gap-2"
                >
                  <Inbox className="w-4.5 h-4.5" /> Kotak Masuk ({inquiryCount})
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
