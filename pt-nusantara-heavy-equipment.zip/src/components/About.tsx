import React from 'react';
import { ABOUT_REAL_IMAGE } from '../data';
import { ShieldCheck, Award, Briefcase, Zap, Star } from 'lucide-react';
import { motion } from 'motion/react';

export default function About() {
  const milestones = [
    { number: 1, title: '2008 - Pendirian Perusahaan', active: true },
    { number: 2, title: '2015 - Ekspansi Armada Nasional', active: true },
    { number: 3, title: '2024 - Transformasi Digital Layanan', active: false }
  ];

  return (
    <section id="about" className="py-24 bg-white font-sans scroll-mt-20">
      <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-16 items-center">
        {/* Visual Column */}
        <div className="relative group">
          {/* Decorative background box */}
          <div className="absolute -top-4 -left-4 w-24 h-24 bg-secondary-container rounded-lg -z-10 transition-transform duration-500 group-hover:scale-110" />
          
          {/* Main depot image */}
          <div className="rounded-2xl overflow-hidden shadow-2xl border border-slate-200 bg-slate-100">
            <img
              className="w-full aspect-4/5 object-cover transition-transform duration-700 group-hover:scale-102"
              alt="Heavy equipment depot at dusk with excavators and cranes aligned"
              src={ABOUT_REAL_IMAGE}
              referrerPolicy="no-referrer"
            />
          </div>

          {/* Safety First Badge floating card */}
          <div className="absolute -bottom-6 -right-6 bg-white/95 backdrop-blur-md p-5 rounded-xl shadow-lg border border-slate-200 hidden md:flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center border border-emerald-300">
              <ShieldCheck className="w-6 h-6 text-emerald-600" />
            </div>
            <div>
              <p className="font-display font-bold text-primary text-sm leading-tight">Safety First</p>
              <p className="text-slate-500 text-xs font-medium">ISO 45001 Certified</p>
            </div>
          </div>
        </div>

        {/* Content Column */}
        <div className="space-y-8">
          <div>
            <span className="text-secondary-container font-sans font-bold text-xs uppercase tracking-widest block mb-2">
              Since 2008
            </span>
            <h2 className="font-display font-extrabold text-2xl md:text-4xl text-primary mb-4 leading-tight">
              Membangun Nusantara dengan Keandalan
            </h2>
            <div className="w-16 h-1 bg-secondary-container rounded-full" />
          </div>

          <p className="text-slate-600 text-sm md:text-base leading-relaxed font-normal">
            PT Nusantara Heavy Equipment bermula dari visi untuk menjadi tulang punggung infrastruktur Indonesia. 
            Kami sangat mengutamakan kualitas prima unit dan profesionalisme operator guna memastikan setiap proyek 
            berjalan secara efisien, presisi, dan aman.
          </p>

          {/* Vision and Mission Grid */}
          <div className="grid grid-cols-2 gap-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-secondary-container/10 border border-secondary-container/30">
                  <Award className="w-5 h-5 text-secondary-container" />
                </div>
                <h4 className="font-display font-bold text-primary text-sm">Visi Kami</h4>
              </div>
              <p className="text-slate-500 text-xs leading-relaxed">
                Menjadi mitra penyewaan alat berat nomor satu pilihan utama industri strategis nasional.
              </p>
            </div>

            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-secondary-container/10 border border-secondary-container/30">
                  <Briefcase className="w-5 h-5 text-secondary-container" />
                </div>
                <h4 className="font-display font-bold text-primary text-sm">Misi Kami</h4>
              </div>
              <p className="text-slate-500 text-xs leading-relaxed">
                Memberikan layanan sewa prima melalui pemeliharaan unit yang ketat sesuai standar OEM.
              </p>
            </div>
          </div>

          {/* Step Timeline */}
          <div className="border-l-4 border-secondary-container pl-6 space-y-4 pt-2">
            {milestones.map((milestone) => (
              <div
                key={milestone.number}
                className={`flex gap-4 items-center transition-opacity duration-300 ${
                  milestone.active ? 'opacity-100' : 'opacity-50'
                }`}
              >
                <div className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center font-bold text-xs flex-shrink-0 shadow-sm">
                  {milestone.number}
                </div>
                <div>
                  <p className="text-xs font-bold text-primary font-sans">{milestone.title}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
