import React, { useState } from 'react';
import { MapPin, Phone, Mail, Send, CheckCircle2, Clock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function Contact() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('Sewa Alat');
  const [message, setMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const errors: Record<string, string> = {};
    if (!name.trim()) errors.name = 'Nama lengkap wajib diisi';
    if (!email.trim()) {
      errors.email = 'Email wajib diisi';
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      errors.email = 'Format email tidak valid';
    }
    if (!message.trim()) errors.message = 'Isi pesan tidak boleh kosong';

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitted(true);
    setTimeout(() => {
      setIsSubmitted(false);
      setName('');
      setEmail('');
      setSubject('Sewa Alat');
      setMessage('');
    }, 4000);
  };

  return (
    <section id="contact" className="py-24 bg-white font-sans scroll-mt-20">
      <div className="max-w-7xl mx-auto px-6">
        {/* Section Heading */}
        <div className="text-center mb-16">
          <span className="text-secondary-container font-bold text-xs uppercase tracking-widest block mb-1">
            Hubungi Kami
          </span>
          <h2 className="font-display font-extrabold text-2xl md:text-4xl text-primary mb-4 leading-tight">
            Siap Memulai Kerja Sama?
          </h2>
          <div className="w-24 h-1 bg-secondary-container mx-auto rounded-full" />
        </div>

        <div className="grid lg:grid-cols-12 gap-12 items-start">
          {/* Info Column (Left) */}
          <div className="lg:col-span-5 space-y-8 bg-slate-900 text-white p-8 md:p-10 rounded-2xl shadow-xl">
            <div className="space-y-3">
              <h3 className="font-display font-extrabold text-xl text-white">Kantor Pusat PT Nusantara</h3>
              <p className="text-slate-300 text-xs md:text-sm leading-relaxed">
                Kunjungi kantor pusat kami atau hubungi kami melalui kanal respon cepat untuk mendiskusikan 
                kebutuhan alat berat proyek Anda secara terperinci.
              </p>
            </div>

            <hr className="border-white/10" />

            <div className="space-y-6">
              {/* Address */}
              <div className="flex gap-4">
                <div className="w-10 h-10 rounded-full bg-white/10 border border-white/15 flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-5 h-5 text-secondary-container" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Alamat Kantor</h4>
                  <p className="text-xs md:text-sm text-slate-200 leading-relaxed font-sans">
                    Kawasan Industri Jababeka, Cikarang, Jawa Barat, Indonesia
                  </p>
                </div>
              </div>

              {/* Call */}
              <div className="flex gap-4">
                <div className="w-10 h-10 rounded-full bg-white/10 border border-white/15 flex items-center justify-center flex-shrink-0">
                  <Phone className="w-5 h-5 text-secondary-container" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Telepon & WhatsApp</h4>
                  <p className="text-xs md:text-sm text-slate-200 leading-relaxed font-sans">
                    +62 21 888 9999 <br />
                    +62 812 3456 7890 (WA Fast Response)
                  </p>
                </div>
              </div>

              {/* Email */}
              <div className="flex gap-4">
                <div className="w-10 h-10 rounded-full bg-white/10 border border-white/15 flex items-center justify-center flex-shrink-0">
                  <Mail className="w-5 h-5 text-secondary-container" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Surel Masuk</h4>
                  <p className="text-xs md:text-sm text-slate-200 leading-relaxed font-sans">
                    info@pt-nusantara.co.id
                  </p>
                </div>
              </div>

              {/* Working Hours */}
              <div className="flex gap-4">
                <div className="w-10 h-10 rounded-full bg-white/10 border border-white/15 flex items-center justify-center flex-shrink-0">
                  <Clock className="w-5 h-5 text-secondary-container" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Jam Operasional</h4>
                  <p className="text-xs md:text-sm text-slate-200 leading-relaxed font-sans">
                    Senin - Sabtu: 08:00 - 17:00 <br />
                    Respon Darurat Teknis Mekanik: 24 Jam Non-Stop
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Form Column (Right) */}
          <div className="lg:col-span-7 bg-slate-50 p-8 md:p-10 rounded-2xl border border-slate-200 shadow-xs relative">
            <AnimatePresence mode="wait">
              {isSubmitted ? (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="flex flex-col items-center justify-center py-16 text-center h-full"
                >
                  <CheckCircle2 className="w-16 h-16 text-emerald-600 mb-4 animate-bounce" />
                  <h4 className="font-display font-extrabold text-xl text-primary mb-2">Pesan Berhasil Terkirim!</h4>
                  <p className="text-slate-600 text-sm max-w-sm leading-relaxed mb-4">
                    Terima kasih <strong>{name}</strong>. Tim administrasi PT Nusantara akan meninjau pesan Anda dan membalas dalam kurun waktu maks. 2 jam kerja.
                  </p>
                  <span className="text-[11px] text-slate-400">Pemberitahuan balasan otomatis telah dikirim ke {email}</span>
                </motion.div>
              ) : (
                <form onSubmit={handleSendMessage} className="space-y-5">
                  <div className="space-y-1">
                    <h3 className="font-display font-bold text-lg text-primary">Kirimkan Pesan Langsung</h3>
                    <p className="text-slate-500 text-xs font-medium">Lengkapi kolom di bawah untuk mengajukan pertanyaan umum seputar sewa atau kustom kerja sama</p>
                  </div>

                  <hr className="border-slate-200" />

                  {/* Name field */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                      Nama Lengkap Anda
                    </label>
                    <input
                      type="text"
                      placeholder="Contoh: Heri Wijaya"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className={`w-full px-3 py-2.5 border rounded-lg text-sm bg-white text-slate-800 placeholder-slate-400 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary ${
                        formErrors.name ? 'border-red-500' : 'border-slate-300'
                      }`}
                    />
                    {formErrors.name && <p className="text-red-500 text-xs mt-1">{formErrors.name}</p>}
                  </div>

                  {/* Email & Subject grid */}
                  <div className="grid sm:grid-cols-2 gap-4">
                    {/* Email */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        Alamat Email Aktif
                      </label>
                      <input
                        type="email"
                        placeholder="Contoh: heriw@gmail.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className={`w-full px-3 py-2.5 border rounded-lg text-sm bg-white text-slate-800 placeholder-slate-400 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary ${
                          formErrors.email ? 'border-red-500' : 'border-slate-300'
                        }`}
                      />
                      {formErrors.email && <p className="text-red-500 text-xs mt-1">{formErrors.email}</p>}
                    </div>

                    {/* Subject */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        Topik Kerja Sama
                      </label>
                      <select
                        value={subject}
                        onChange={(e) => setSubject(e.target.value)}
                        className="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm bg-white text-slate-800 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary"
                      >
                        <option value="Sewa Alat">Sewa Alat Berat Standard</option>
                        <option value="Kontrak Jangka Panjang">Kontrak Jangka Panjang (B2B)</option>
                        <option value="Layanan Operator">Pertanyaan Karir Operator</option>
                        <option value="Lainnya">Kustom Kerja Sama Lainnya</option>
                      </select>
                    </div>
                  </div>

                  {/* Message field */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                      Isi Detail Pesan Anda
                    </label>
                    <textarea
                      placeholder="Tuliskan secara jelas kebutuhan Anda, jenis proyek, durasi, dll..."
                      rows={4}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      className={`w-full px-3 py-2.5 border rounded-lg text-sm bg-white text-slate-800 placeholder-slate-400 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary ${
                        formErrors.message ? 'border-red-500' : 'border-slate-300'
                      }`}
                    />
                    {formErrors.message && <p className="text-red-500 text-xs mt-1">{formErrors.message}</p>}
                  </div>

                  {/* Submit Button */}
                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full bg-primary hover:brightness-110 active:scale-98 text-white py-3.5 rounded-lg text-xs font-bold font-display uppercase tracking-wider shadow-sm transition-all flex items-center justify-center gap-2"
                    >
                      Kirim Pesan Ke Admin <Send className="w-4 h-4" />
                    </button>
                  </div>
                </form>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}
