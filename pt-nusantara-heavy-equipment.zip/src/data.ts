import { Equipment, Project, FAQItem } from './types';

export const HERO_BG_IMAGE = 'https://lh3.googleusercontent.com/aida-public/AB6AXuDFkg2t64aLWtVGyKA8uPjkwY_rGzYLEiI7zmUIbYQGtduKaOPwyDI-eK94WqtcMYgrrgAFEh5ONznWHl68HhI3Gl_Sp7UEvL-6ugP0BTzVExPA8v0ckY7hNSoyrZopbWNR0D4OrBbQmiy264UkFkIQTrVI_PIVN6NlZBqa26vGMx2ORRLtRKajEVVBYRC5UJZR4tIMwUVDikZqwvNlcwuQkX7OFaEZqR4IIdo1y22Xyot2bMkNan87XW0d9JxDziIQByqqW4Ua-th7';

export const ABOUT_IMAGE = 'https://lh3.googleusercontent.com/aida-public/AB6AXuBdaVRArrg_about_placeholder_if_broken_or_real_is_this_one_lh3_or_another';
// Wait, the real about image in HTML was:
export const ABOUT_REAL_IMAGE = 'https://lh3.googleusercontent.com/aida-public/AB6AXuBdaVRDj7dhWcqBtg55HPXz3J6ovzzbrHNOakQP8_Sm7A6vdvK1eAqSDtryfmQ9D0HV9mzCmWY1DT9peVsk_IVqlUA1VY0wtRjSQRaeriKiFtBTH7pXCRZQC2lzO1qgK2H7Qs4toSvEkNXjNX7X3MpCaYJllIXjzrHMKmcTTK5r3LHyAFfJs5PsX5Ea8bA_qp-JnDkkioXxNhEVsb5fWPKd8DfMU-l9HAf_UdIiAJz5jPZvbm2YzxBoQMU73Y6l5EAJZJdmkxtCWmqn';

export const EQUIPMENTS: Equipment[] = [
  {
    id: 'eq-1',
    name: 'Caterpillar 320D',
    category: 'Excavator',
    model: 'Excavator Hydraulic',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAUVJz-9-hFaFnDS8UUx9CNESV2nZ-NM-JjDvckvhvKkLnHB1DrcZSohBHitiKg0jywyRSe489QgqkXPB38YYVr6wRG_FKRlSxQB-WSim53Ic3Mfoj7Fl8mYaFSZBWM-FsClu39Rokh9vBCatGJU6rpnngfVn2TJfsMsad0hiBPMQNeHfBHy1EvK6DXr3WI5yAwNwIm_X8Tq4uJiZL4u_taVUfnPRF82eFrCHsY-xWhcNhtwGUWto3FX1FL17hkLIC0tmuOZzm9nDol',
    status: 'Available',
    specs: {
      weight: '20.3 Ton',
      year: 2021
    },
    description: 'Excavator standar industri untuk produktivitas tinggi. Sistem perawatan berkala yang ketat mengikuti standar pabrikan (OEM) untuk meminimalkan downtime.',
    features: ['Sistem Hidrolik Responsif', 'Konsumsi Bahan Bakar Efisien', 'Kabin Ergonomis & AC Dingin', 'Lengkap dengan Operator Berpengalaman'],
    rentalPrice: 'Rp 4.200.000 / Shift (8 Jam)'
  },
  {
    id: 'eq-2',
    name: 'Komatsu D85ESS',
    category: 'Bulldozer',
    model: 'Bulldozer Medium',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB-9jg4YVBQ3Ei4orY8zyxrm7PVtFd2HoV4yjFstXE7mW7OZejy_Z-NlKljXHSR5r7W0czHkA2zCCX8hduhv3ctnw6uen7CdKxU-izTdq124ivYWXu3VyldV1LUVT9ID42si2xD8d9gt9RIASAm_yMz8JyKjbNTVveGx9bNz0Urq3UEDBhUqYVotUbv0FaT2BG620dgIxYJcCERfOIfHQwxLhMSC3ZqqzUJxIdJuKI_i-JHuD0iS7TXq1sNcNwGBkCMoVeAKxq8CUHU',
    status: 'Available',
    specs: {
      power: '200 HP',
      year: 2022
    },
    description: 'Bulldozer tangguh berukuran medium, ideal untuk perataan lahan, konstruksi jalan, dan pengerjaan tambang ringan.',
    features: ['Pisau Lebar (Blade) Efisiensi Tinggi', 'Sistem Kemudi Joystick', 'Daya Dorong Maksimal', 'Sertifikasi K3 & SIO Aktif'],
    rentalPrice: 'Rp 4.800.000 / Shift (8 Jam)'
  },
  {
    id: 'eq-3',
    name: 'Kobelco 7055',
    category: 'Crane',
    model: 'Crawler Crane',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDPDLigLlZMjH53oLjpG7-WooT1ekj2Tl_WdypE3Zzoq5Dg3ghMfscJZ5SxikJHKfJQQqnYPRbOMp9Pzk1I26R7dVat2-5b9cCVYrtloDmkyIL_SgJqOwQzR8YGff9kU0uT1fe3X3XWSgW_vAdqfT5bgAqB1_SmqMpSyGvAXoTTDsJ9cWAll_KjkPAzrFiL75EJv3syn-J8cGrznxs03rXaAkubCcN12r1u1oDSBcB0lUrXwqoY-hZnDvn-N3cZxzxexOFbDMzFnUUk',
    status: 'On Rent',
    specs: {
      capacity: '55 Ton',
      year: 2020
    },
    description: 'Crawler crane berkapasitas 55 Ton untuk pengangkatan material tinggi di proyek gedung bertingkat dan jembatan.',
    features: ['Panjang Boom Fleksibel', 'Keseimbangan Sangat Stabil', 'Sistem Keselamatan Overload Alarm', 'Operator Bersertifikat Kelas 1'],
    rentalPrice: 'Rp 6.500.000 / Shift (8 Jam)'
  },
  {
    id: 'eq-4',
    name: 'Scania P360',
    category: 'Dump Truck',
    model: 'Dump Truck',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD322rg9ryqpnomDFFeEivniI3KkZsWqbfTJZB_p70RQCc6hiBLxIUyhAzjdPc21BjDUhS3S4kVtDSiF71r0sj0yBuUwfm6kmvbuWDKa1k3Lpt-GZJiCjMOJEZ9a-Ic8wg34zPyp8SGvFaOC1a4tE44vJM58Gx5itBncCq9w9EyEhbjftcmK9FVaWGI96EjQoB3eaijYGQlBljIccfcrJ-7GImLBBY1ytR7Qb29XHHf-z-RJU2cpF4DF49Ry7FEHzzV2RFQ4du0DZgo',
    status: 'Available',
    specs: {
      capacity: '20 m³',
      year: 2023
    },
    description: 'Truk jungkit bermuatan besar dengan sasis kokoh untuk logistik material tanah, batu pecah, batubara, dan mineral tambang.',
    features: ['Mesin Euro 4 Ramah Lingkungan', 'Kapasitas Bak 20 Meter Kubik', 'Transmisi Otomatis Opticruise', 'Suspensi Heavy-Duty untuk Medan Berat'],
    rentalPrice: 'Rp 3.500.000 / Shift (8 Jam)'
  },
  // Extra items to make the filters even richer!
  {
    id: 'eq-5',
    name: 'Hitachi ZX210-5G',
    category: 'Excavator',
    model: 'Excavator Medium',
    image: 'https://images.unsplash.com/photo-1579226905180-636b76d96082?auto=format&fit=crop&q=80&w=800',
    status: 'Available',
    specs: {
      weight: '21.1 Ton',
      year: 2022
    },
    description: 'Excavator medium yang lincah dan bertenaga untuk galian foundation, perataan tanah, dan pemuatan material ke dump truck.',
    features: ['Sistem Kelistrikan Handal', 'Perawatan Sederhana', 'Konsumsi Solar Rendah', 'Sertifikasi SIO Siap Sedia'],
    rentalPrice: 'Rp 4.000.000 / Shift (8 Jam)'
  },
  {
    id: 'eq-6',
    name: 'CAT D6R',
    category: 'Bulldozer',
    model: 'Bulldozer Heavy Duty',
    image: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&q=80&w=800',
    status: 'On Rent',
    specs: {
      power: '185 HP',
      year: 2020
    },
    description: 'Bulldozer heavy-duty untuk pengerjaan pembukaan lahan hutan (land clearing) dan reklamasi area industri strategis.',
    features: ['Diferensial Steering Sistem', 'Torsi Mesin Tinggi', 'Undercarriage Sangat Kuat', 'Lengkap dengan Operator Khusus'],
    rentalPrice: 'Rp 5.200.000 / Shift (8 Jam)'
  },
  {
    id: 'eq-7',
    name: 'Sany SCC1000A',
    category: 'Crane',
    model: 'Crawler Crane Heavy',
    image: 'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&q=80&w=800',
    status: 'Maintenance',
    specs: {
      capacity: '100 Ton',
      year: 2019
    },
    description: 'Crawler crane berkapasitas raksasa 100 Ton untuk pengangkatan turbin, tiang pancang beton masif, dan balok jembatan panjang.',
    features: ['Kapasitas Angkat Ekstrim 100t', 'Keamanan Level Tinggi dengan Komputerisasi LMI', 'Sertifikasi Kelayakan Dinas Tenaga Kerja', 'Pemeriksaan Rutin Setiap Pekan'],
    rentalPrice: 'Rp 9.500.000 / Shift (8 Jam)'
  }
];

export const PROJECTS: Project[] = [
  {
    id: 'proj-1',
    title: 'Jalan Tol Trans-Jawa Section 4',
    category: 'Roads & Bridges',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAop9TWW9MmH6O4POw2goKb9YNwvmk3jEqQhuzbeoYABHjdyfpbBKHkjggaBSmCwnn_THt4KPr5gR97kbDYgKkO-DAcJ252D39p0suMCCIHvo2iEXnHfN0-8IbN0rdkn1vnPfEZIu0LnuHvAhP_LgaZBLKkP_2QmU2WjmQVXsabw4YicCN5Mu-Q8IkB8AgeX74D5-X1PA1GHBYTu9Ybjhpw82Mlfcp-mPTBbGh2aw_ePnFzBeg6mUQKPjYkpkyuQpicMbVDmPgO60wr',
    location: 'Jawa Tengah & Jawa Timur',
    equipmentUsed: ['Caterpillar 320D', 'Komatsu D85ESS', 'Scania P360'],
    year: 2023,
    description: 'Penyediaan armada excavator, buldozer, dan dump truck secara intensif selama 12 bulan penuh untuk mendukung percepatan konstruksi tanah urugan dan struktur jalan utama.'
  },
  {
    id: 'proj-2',
    title: 'Tambang Batubara Kalimantan',
    category: 'Mining',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCbkfRgn8lSbk5j5m5XXmAmbt9881LOpnJ84PxpvQwMgTpIUDxc00j5AwYm0cHuMGwjkmp4ec4UYYCFojOmT-uRp0mnnkV2ck-D_CpsbcDSVRmJBsV3V29a7PVbE_A9q3sVlR-pTQLsG2eXOmnY9Hd8I4477J-dndrMHfIsAlykHnKbTufvt8MRQ75iFi08dqHp9R9dqG3tEL24tos17XnaR6fJzgMWqEVe_4bdOyyQYyaI5saNe0B5CDlOUoX5c5DieeV5VQxKeXPB',
    location: 'Kalimantan Timur',
    equipmentUsed: ['Scania P360', 'Caterpillar 320D', 'Heavy Excavators'],
    year: 2022,
    description: 'Mobilisasi armada truk pengangkut dump truck Scania P360 dan excavator Caterpillar berdaya besar untuk pengupasan lapisan tanah (overburden removal) serta pengangkutan batubara dari pit ke stockpile.'
  },
  {
    id: 'proj-3',
    title: 'Pusat Perkantoran SCBD',
    category: 'Building Construction',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAWWjfdEWr6hvA8PvQVHmdA-CV7o8dtMMyQfEMzlQY34FSaJkp5zLiof3U3W5uFYf3JQuCV8mUiMO_RM8u15F82cPjZIKjXIRlEBGa7ligX8WLQlxsTlGIHBINTbKg1bQp0g1SHeiW0URMfRApMDuPmjsFl8KRoGF7rq6jIq4CFhKu-5_gL9KlWj955tvnh7iZNGMyeLt5AZUdMimRlASQiD67kTnzCTiJMSUy3qSRBOQTkGut4O6iMa4SImR_rLIkzTXHpcROQoKwB',
    location: 'Jakarta Selatan',
    equipmentUsed: ['Kobelco 7055', 'Sany SCC1000A'],
    year: 2024,
    description: 'Penyewaan crawler crane kapasitas 55 Ton dan 100 Ton bersertifikasi kelayakan resmi dari Disnaker untuk penempatan struktur baja berat, material beton pra-cetak, dan logistik vertikal beresiko tinggi.'
  }
];

export const FAQS: FAQItem[] = [
  {
    id: 'faq-1',
    question: 'Apakah harga sewa sudah termasuk operator?',
    answer: 'Ya, paket sewa standar kami sudah termasuk operator yang bersertifikat resmi (SIO Aktif) dan berpengalaman luas di berbagai medan. Kami juga menyediakan opsi lepas kunci untuk korporasi/B2B tertentu yang memiliki operator internal yang tersertifikasi dan lolos kualifikasi dari tim keselamatan kerja kami.'
  },
  {
    id: 'faq-2',
    question: 'Berapa lama periode minimum penyewaan?',
    answer: 'Periode sewa minimum bervariasi berdasarkan tipe alat berat. Untuk unit konstruksi jalan/galian ringan minimum penyewaan adalah 50 jam kerja efektif. Sedangkan untuk unit kelas berat dan pertambangan (seperti crawler crane besar & dump truck heavy-duty), minimum kontrak sewa adalah 200 jam kerja efektif per bulan.'
  },
  {
    id: 'faq-3',
    question: 'Wilayah mana saja yang dapat dilayani?',
    answer: 'Kami melayani pengiriman unit alat berat dan penugasan operator ke seluruh pelosok wilayah Indonesia, termasuk daerah pedalaman/remote area untuk pengerjaan pertambangan batu bara, nikel, emas, hingga perkebunan kelapa sawit dengan dukungan tim logistik ekspedisi darat dan laut yang sangat terlatih.'
  },
  {
    id: 'faq-4',
    question: 'Bagaimana penanganan jika terjadi kerusakan teknis di lokasi?',
    answer: 'Tim mekanik kami standby 24 jam sehari, 7 hari seminggu. Kami memiliki pusat layanan darurat yang akan memobilisasi mekanik berpengalaman ke lokasi proyek Anda dalam kurun waktu kurang dari 4 jam sejak pelaporan. Jika kerusakan bersifat mayor dan membutuhkan perbaikan lama, kami akan menyediakan unit pengganti (backup unit) yang setara untuk memastikan proyek Anda tidak terhenti.'
  },
  {
    id: 'faq-5',
    question: 'Bagaimana dengan penjaminan mutu dan keselamatan kerja (K3)?',
    answer: 'PT Nusantara Heavy Equipment memegang sertifikasi sistem manajemen keselamatan kerja ISO 45001. Semua unit kami melewati inspeksi berkala sebelum dikirim ke lapangan dan dilengkapi dengan Surat Izin Layak Operasi (SILO) yang diterbitkan secara resmi oleh instansi berwenang.'
  }
];

export const WHY_CHOOSE_US = [
  {
    iconName: 'engineering', // will map to Lucide icon: Settings/Wrench
    title: 'Unit Terawat',
    description: 'Sistem perawatan berkala yang sangat ketat mengikuti rekomendasi standar pabrikan (OEM) guna memastikan keandalan mekanik tertinggi dan meminimalkan downtime di lapangan.'
  },
  {
    iconName: 'badge', // will map to Lucide icon: ShieldCheck/Award
    title: 'Operator Bersertifikasi',
    description: 'Seluruh tim operator kami memiliki Surat Izin Operasional (SIO) resmi, lulus uji kompetensi ketat, serta berpengalaman di medan ekstrim.'
  },
  {
    iconName: 'payments', // will map to Lucide icon: Banknote/BadgeDollarSign
    title: 'Harga Kompetitif',
    description: 'Struktur penetapan tarif sewa yang sangat transparan, bersahabat untuk anggaran proyek skala kecil hingga mega-proyek nasional, tanpa biaya tersembunyi.'
  },
  {
    iconName: 'support_agent', // will map to Lucide icon: Headphones/Clock
    title: 'Support Teknis 24/7',
    description: 'Mekanik standby yang selalu siaga merespons kendala dengan suku cadang asli dan siap melakukan inspeksi langsung ke lokasi proyek.'
  },
  {
    iconName: 'public', // will map to Lucide icon: Globe2
    title: 'Jangkauan Luas',
    description: 'Konektivitas armada logistik tronton internal yang handal memudahkan pengiriman unit ke seluruh wilayah kepulauan Indonesia.'
  },
  {
    iconName: 'health_and_safety', // will map to Lucide icon: HeartHandshake/FlameKindling
    title: 'Prioritas Keamanan',
    description: 'Penerapan standar keselamatan kerja K3 tingkat tinggi di setiap lokasi operasional guna mewujudkan komitmen nol kecelakaan kerja (Zero Accident).'
  }
];
