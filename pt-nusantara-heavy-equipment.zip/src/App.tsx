import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Catalog from './components/Catalog';
import WhyChooseUs from './components/WhyChooseUs';
import Portfolio from './components/Portfolio';
import Process from './components/Process';
import FAQ from './components/FAQ';
import Contact from './components/Contact';
import FinalCTA from './components/FinalCTA';
import Footer from './components/Footer';
import FloatingWA from './components/FloatingWA';
import BookingModal from './components/BookingModal';
import AdminInbox from './components/AdminInbox';
import { Equipment, Inquiry } from './types';
import { EQUIPMENTS } from './data';
import { Sparkles, Eye, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const INITIAL_INQUIRIES: Inquiry[] = [
  {
    id: 'inq-1',
    equipmentId: 'eq-1',
    equipmentName: 'Caterpillar 320D',
    customerName: 'CV Jasa Konstruksi Mulia',
    customerEmail: 'mulia.konstruksi@gmail.com',
    customerPhone: '081298765432',
    startDate: '2026-07-01',
    duration: 10,
    isOperatorNeeded: true,
    notes: 'Butuh pengiriman cepat ke site di Karawang Barat. Pekerjaan perataan base-course jalan.',
    createdAt: new Date(Date.now() - 3 * 3600 * 1000).toISOString(), // 3 hours ago
    status: 'Pending'
  },
  {
    id: 'inq-2',
    equipmentId: 'eq-4',
    equipmentName: 'Scania P360',
    customerName: 'PT Borneo Mining Lestari',
    customerEmail: 'procurement@borneomining.com',
    customerPhone: '081122334455',
    startDate: '2026-07-15',
    duration: 30,
    isOperatorNeeded: false,
    notes: 'Sewa lepas kunci bulanan untuk penempatan di area tambang Sangatta.',
    createdAt: new Date(Date.now() - 18 * 3600 * 1000).toISOString(), // 18 hours ago
    status: 'Approved'
  }
];

export default function App() {
  const [inquiries, setInquiries] = useState<Inquiry[]>(() => {
    const saved = localStorage.getItem('nusantara_inquiries');
    return saved ? JSON.parse(saved) : INITIAL_INQUIRIES;
  });

  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [isAdminInboxOpen, setIsAdminInboxOpen] = useState(false);
  const [selectedEquipmentForBooking, setSelectedEquipmentForBooking] = useState<Equipment | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    localStorage.setItem('nusantara_inquiries', JSON.stringify(inquiries));
  }, [inquiries]);

  const handleInquirySubmitted = (newInquiry: Inquiry) => {
    setInquiries((prev) => [newInquiry, ...prev]);
    showToast(`Quotation sewa untuk ${newInquiry.customerName} telah sukses terdaftar!`);
  };

  const handleUpdateStatus = (id: string, status: 'Pending' | 'Approved' | 'Rejected') => {
    setInquiries((prev) =>
      prev.map((inq) => (inq.id === id ? { ...inq, status } : inq))
    );
    showToast(`Status pengajuan ${id} berhasil diubah menjadi: ${status === 'Approved' ? 'Disetujui' : 'Ditolak'}`);
  };

  const handleDeleteInquiry = (id: string) => {
    if (window.confirm('Apakah Anda yakin ingin menghapus arsip pengajuan sewa ini?')) {
      setInquiries((prev) => prev.filter((inq) => inq.id !== id));
      showToast(`Arsip pengajuan ${id} berhasil dihapus.`);
    }
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4500);
  };

  const handleSewaClick = (equipment: Equipment) => {
    setSelectedEquipmentForBooking(equipment);
    setIsBookingOpen(true);
  };

  const handleGeneralRequestQuoteClick = () => {
    setSelectedEquipmentForBooking(null);
    setIsBookingOpen(true);
  };

  return (
    <div className="bg-slate-50 text-slate-800 font-sans overflow-x-hidden min-h-screen">
      {/* Top Banner alert explaining the interactive Admin Inbox feature */}
      <div className="bg-amber-500 text-slate-900 text-xs py-2 px-4 text-center font-bold relative z-50 flex items-center justify-center gap-2">
        <Sparkles className="w-4 h-4 animate-spin-slow" />
        <span>Fitur Interaktif: Ajukan sewa melalui tombol 'Sewa Sekarang' dan lihat kalkulasi biaya serta statusnya di Kotak Masuk!</span>
      </div>

      {/* Header Navigation */}
      <Header
        onRequestQuoteClick={handleGeneralRequestQuoteClick}
        onInboxClick={() => setIsAdminInboxOpen(true)}
        inquiryCount={inquiries.filter((i) => i.status === 'Pending').length}
      />

      {/* Core Landings Page Layout */}
      <main className="relative">
        <Hero onMintaPenawaranClick={handleGeneralRequestQuoteClick} />
        
        <About />
        
        <Catalog onSewaClick={handleSewaClick} />
        
        <WhyChooseUs />
        
        <Portfolio />
        
        <Process />
        
        <FAQ />
        
        <Contact />
        
        <FinalCTA onMintaPenawaranClick={handleGeneralRequestQuoteClick} />
      </main>

      {/* Footer information */}
      <Footer />

      {/* Floating Action WhatsApp and Tooltip */}
      <FloatingWA />

      {/* Interactive Booking Modal Form */}
      <BookingModal
        isOpen={isBookingOpen}
        onClose={() => setIsBookingOpen(false)}
        selectedEquipment={selectedEquipmentForBooking}
        equipmentsList={EQUIPMENTS}
        onInquirySubmitted={handleInquirySubmitted}
      />

      {/* Interactive Admin Inbox / Submission Viewer Drawer */}
      <AdminInbox
        isOpen={isAdminInboxOpen}
        onClose={() => setIsAdminInboxOpen(false)}
        inquiries={inquiries}
        onUpdateStatus={handleUpdateStatus}
        onDeleteInquiry={handleDeleteInquiry}
      />

      {/* Global Action Toast Notification Banner */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-6 left-6 z-50 max-w-sm bg-slate-900/95 backdrop-blur-xs text-white p-4 rounded-xl shadow-2xl border border-white/10 text-xs font-medium flex items-center gap-3"
          >
            <div className="w-6 h-6 bg-secondary-container rounded-full flex items-center justify-center text-primary flex-shrink-0">
              ✓
            </div>
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

