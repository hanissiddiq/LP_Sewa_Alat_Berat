export type EquipmentCategory = 'Semua' | 'Excavator' | 'Bulldozer' | 'Crane' | 'Dump Truck';

export type EquipmentStatus = 'Available' | 'On Rent' | 'Maintenance';

export interface EquipmentSpecs {
  weight?: string;
  power?: string;
  capacity?: string;
  year: number;
}

export interface Equipment {
  id: string;
  name: string;
  category: EquipmentCategory;
  model: string;
  image: string;
  status: EquipmentStatus;
  specs: EquipmentSpecs;
  description: string;
  features: string[];
  rentalPrice: string; // e.g. "Rp 4.500.000 / Shift" or similar
}

export interface Project {
  id: string;
  title: string;
  category: string;
  image: string;
  location: string;
  equipmentUsed: string[];
  year: number;
  description: string;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
}

export interface Inquiry {
  id: string;
  equipmentId: string;
  equipmentName: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  startDate: string;
  duration: number;
  isOperatorNeeded: boolean;
  notes: string;
  createdAt: string;
  status: 'Pending' | 'Approved' | 'Rejected';
}
